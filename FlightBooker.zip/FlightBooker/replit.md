# Overview

FlyJordanAirline is a comprehensive airline website built as a modern, mobile-first React application. The project features a complete airline booking system with flight search functionality, destination showcases, fleet information, company details, a blog section, and contact capabilities. The application is designed to provide users with a premium airline experience through clean UI design and smooth user interactions.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing with support for dynamic routes like `/blog/:slug`
- **Styling**: TailwindCSS with custom design system using turquoise (#22B8CF) and gold (#C9A227) brand colors
- **Component Library**: Shadcn/ui providing a comprehensive set of accessible, customizable components
- **Animations**: Framer Motion for smooth page transitions and micro-interactions
- **State Management**: TanStack React Query for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for type-safe form processing

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for end-to-end type safety
- **API Design**: RESTful endpoints for contact submissions and flight searches
- **Data Storage**: In-memory storage with interface-based design allowing easy migration to persistent databases
- **Validation**: Zod schemas shared between frontend and backend for consistent validation

## Data Storage Solutions
- **Current Implementation**: MemStorage class providing in-memory data persistence
- **Database Ready**: Drizzle ORM configured for PostgreSQL with schema definitions and migrations
- **Schema Design**: Structured tables for users, contact submissions, and flight searches with proper relationships

## Authentication and Authorization
- **Architecture**: Session-based authentication infrastructure prepared but not currently implemented
- **Storage**: Session management configured with connect-pg-simple for PostgreSQL session store
- **Future Ready**: User schema and authentication endpoints structured for easy implementation

## Build and Development
- **Build Tool**: Vite for fast development and optimized production builds
- **Development**: Hot Module Replacement (HMR) and development middleware integration
- **Production**: Optimized bundle splitting and static asset serving
- **TypeScript**: Strict type checking with path mapping for clean imports

# External Dependencies

## Database and ORM
- **Drizzle ORM**: Modern TypeScript ORM with PostgreSQL dialect configuration
- **Neon Database**: Serverless PostgreSQL database service for scalable data storage
- **Migration System**: Automated database schema management with version control

## UI and Styling
- **Radix UI**: Comprehensive set of accessible UI primitives for complex components
- **Tailwind CSS**: Utility-first CSS framework with custom design system configuration
- **Framer Motion**: Animation library for smooth transitions and micro-interactions
- **Lucide React**: Icon library providing consistent iconography throughout the application

## Form and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation with runtime type checking
- **Hookform Resolvers**: Integration layer connecting React Hook Form with Zod validation

## Development and Build Tools
- **Vite**: Next-generation frontend build tool with fast development server
- **TypeScript**: Static type checking and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer for cross-browser compatibility

## Date and Utility Libraries
- **Date-fns**: Modern date utility library for date manipulation and formatting
- **Class Variance Authority**: Utility for creating variant-based component APIs
- **clsx**: Utility for constructing className strings conditionally