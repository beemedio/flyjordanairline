import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plane, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

export default function Footer() {
  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Newsletter subscription logic would go here
    alert("Newsletter subscription functionality would be implemented here!");
  };

  return (
    <footer className="bg-dark-gray text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-6">
              <Plane className="h-6 w-6 text-primary mr-3" />
              <span className="text-2xl font-bold">FlyJordanAirline</span>
            </div>
            <p className="text-gray-300 mb-6">
              Your trusted partner for premium air travel experiences connecting you to destinations worldwide.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="w-10 h-10 bg-primary bg-opacity-20 rounded-lg flex items-center justify-center hover:bg-opacity-30 transition-colors"
                data-testid="link-facebook"
              >
                <Facebook className="h-5 w-5 text-primary" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-primary bg-opacity-20 rounded-lg flex items-center justify-center hover:bg-opacity-30 transition-colors"
                data-testid="link-twitter"
              >
                <Twitter className="h-5 w-5 text-primary" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-primary bg-opacity-20 rounded-lg flex items-center justify-center hover:bg-opacity-30 transition-colors"
                data-testid="link-instagram"
              >
                <Instagram className="h-5 w-5 text-primary" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-primary bg-opacity-20 rounded-lg flex items-center justify-center hover:bg-opacity-30 transition-colors"
                data-testid="link-linkedin"
              >
                <Linkedin className="h-5 w-5 text-primary" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-book-flight">
                  Book a Flight
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-manage-booking">
                  Manage Booking
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-check-in">
                  Check-in Online
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-flight-status">
                  Flight Status
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-baggage-info">
                  Baggage Info
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-special-assistance">
                  Special Assistance
                </a>
              </li>
            </ul>
          </div>

          {/* Destinations */}
          <div>
            <h3 className="text-lg font-bold mb-6">Popular Destinations</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/destinations" data-testid="link-dest-amman">
                  <a className="text-gray-300 hover:text-white transition-colors">Amman, Jordan</a>
                </Link>
              </li>
              <li>
                <Link href="/destinations" data-testid="link-dest-paris">
                  <a className="text-gray-300 hover:text-white transition-colors">Paris, France</a>
                </Link>
              </li>
              <li>
                <Link href="/destinations" data-testid="link-dest-dubai">
                  <a className="text-gray-300 hover:text-white transition-colors">Dubai, UAE</a>
                </Link>
              </li>
              <li>
                <Link href="/destinations" data-testid="link-dest-newyork">
                  <a className="text-gray-300 hover:text-white transition-colors">New York, USA</a>
                </Link>
              </li>
              <li>
                <Link href="/destinations" data-testid="link-dest-london">
                  <a className="text-gray-300 hover:text-white transition-colors">London, UK</a>
                </Link>
              </li>
              <li>
                <Link href="/destinations" data-testid="link-dest-cairo">
                  <a className="text-gray-300 hover:text-white transition-colors">Cairo, Egypt</a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-bold mb-6">Stay Updated</h3>
            <p className="text-gray-300 mb-4">
              Subscribe to our newsletter for the latest deals and travel updates.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="space-y-3">
              <Input
                type="email"
                placeholder="Enter your email"
                className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:ring-primary focus:border-primary"
                data-testid="input-newsletter-email"
                required
              />
              <Button
                type="submit"
                className="w-full bg-primary text-white py-3 rounded-xl font-semibold hover:bg-opacity-90 transition-colors"
                data-testid="button-newsletter-subscribe"
              >
                Subscribe
              </Button>
            </form>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="pt-8 border-t border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 text-sm mb-4 md:mb-0">
              © 2023 FlyJordanAirline. All rights reserved.
            </p>
            <div className="flex flex-wrap gap-6 text-sm">
              <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-privacy">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-terms">
                Terms of Service
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-cookies">
                Cookie Policy
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors" data-testid="link-accessibility">
                Accessibility
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
