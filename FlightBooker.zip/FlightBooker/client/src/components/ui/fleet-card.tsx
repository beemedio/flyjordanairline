import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Wifi, Monitor, Zap, Coffee } from "lucide-react";

interface FleetCardProps {
  aircraft: {
    id: string;
    name: string;
    type: string;
    passengers: number;
    range: number;
    image: string;
    amenities: string[];
  };
  index: number;
}

const amenityIcons = {
  "Wi-Fi": Wifi,
  "Entertainment": Monitor,
  "Power Outlets": Zap,
  "Premium Dining": Coffee,
  "Extra Legroom": Monitor,
  "Quick Boarding": Zap,
};

export default function FleetCard({ aircraft, index }: FleetCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="bg-white rounded-2xl shadow-xl overflow-hidden h-full">
        <img
          src={aircraft.image}
          alt={aircraft.name}
          className="w-full h-64 object-cover"
          data-testid={`img-aircraft-${aircraft.id}`}
        />
        <CardContent className="p-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-2xl font-bold text-dark-gray" data-testid={`text-aircraft-name-${aircraft.id}`}>
              {aircraft.name}
            </h3>
            <Badge 
              className={`${aircraft.type === 'Long-haul' ? 'bg-primary' : 'bg-secondary'} text-white`}
              data-testid={`badge-aircraft-type-${aircraft.id}`}
            >
              {aircraft.type}
            </Badge>
          </div>
          
          <p className="text-gray-600 mb-6" data-testid={`text-aircraft-description-${aircraft.id}`}>
            {aircraft.type === 'Long-haul' 
              ? 'Experience ultimate comfort on long-haul flights with advanced cabin pressure, larger windows, and quieter operation.'
              : 'Perfect for regional routes with fuel-efficient engines, spacious cabin, and enhanced passenger comfort.'
            }
          </p>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="text-center p-4 bg-gray-50 rounded-xl">
              <div className="text-2xl font-bold text-primary mb-1" data-testid={`text-aircraft-passengers-${aircraft.id}`}>
                {aircraft.passengers}
              </div>
              <div className="text-sm text-gray-600">Passengers</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-xl">
              <div className="text-2xl font-bold text-secondary mb-1" data-testid={`text-aircraft-range-${aircraft.id}`}>
                {aircraft.range.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Range (km)</div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-6">
            {aircraft.amenities.map((amenity, idx) => {
              const IconComponent = amenityIcons[amenity as keyof typeof amenityIcons] || Monitor;
              return (
                <span
                  key={idx}
                  className={`${aircraft.type === 'Long-haul' ? 'bg-primary bg-opacity-10 text-primary' : 'bg-secondary bg-opacity-10 text-secondary'} px-3 py-1 rounded-full text-sm flex items-center gap-1`}
                  data-testid={`amenity-${aircraft.id}-${idx}`}
                >
                  <IconComponent className="h-3 w-3" />
                  {amenity}
                </span>
              );
            })}
          </div>

          <Button 
            className={`w-full ${aircraft.type === 'Long-haul' ? 'bg-primary' : 'bg-secondary'} text-white py-3 rounded-xl font-semibold hover:bg-opacity-90 transition-colors`}
            data-testid={`button-view-details-${aircraft.id}`}
          >
            View Aircraft Details
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}
