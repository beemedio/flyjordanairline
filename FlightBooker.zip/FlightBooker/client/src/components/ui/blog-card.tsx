import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";

interface BlogCardProps {
  post: {
    id: string;
    title: string;
    excerpt: string;
    category: string;
    readTime: string;
    date: string;
    image: string;
    slug: string;
  };
  index: number;
}

export default function BlogCard({ post, index }: BlogCardProps) {
  const categoryColors = {
    "Travel Tips": "bg-primary text-white",
    "Destinations": "bg-secondary text-white", 
    "Airline News": "bg-primary text-white",
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="card-hover bg-white rounded-2xl shadow-lg overflow-hidden h-full flex flex-col">
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-48 object-cover"
          data-testid={`img-blog-${post.id}`}
        />
        <CardContent className="p-6 flex-1 flex flex-col">
          <div className="flex items-center mb-3">
            <Badge 
              className={categoryColors[post.category as keyof typeof categoryColors] || "bg-primary text-white"}
              data-testid={`badge-category-${post.id}`}
            >
              {post.category}
            </Badge>
            <span className="text-gray-500 text-sm ml-3" data-testid={`text-read-time-${post.id}`}>
              {post.readTime} read
            </span>
          </div>
          <h3 className="text-xl font-bold text-dark-gray mb-3 flex-1" data-testid={`text-blog-title-${post.id}`}>
            {post.title}
          </h3>
          <p className="text-gray-600 mb-4" data-testid={`text-blog-excerpt-${post.id}`}>
            {post.excerpt}
          </p>
          <div className="flex items-center justify-between mt-auto">
            <span className="text-gray-500 text-sm" data-testid={`text-blog-date-${post.id}`}>
              {post.date}
            </span>
            <Link href={`/blog/${post.slug}`} data-testid={`link-blog-${post.id}`}>
              <Button variant="ghost" className="text-primary font-semibold hover:underline p-0">
                Read More
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </motion.article>
  );
}
