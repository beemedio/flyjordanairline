import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plane, Search, Calendar, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const flightSearchSchema = z.object({
  from: z.string().min(1, "Please select departure city"),
  to: z.string().min(1, "Please select destination"),
  departureDate: z.string().min(1, "Please select departure date"),
  returnDate: z.string().optional(),
  passengers: z.string().min(1, "Please select number of passengers"),
  class: z.string().min(1, "Please select travel class"),
  tripType: z.string().min(1, "Please select trip type"),
});

type FlightSearchForm = z.infer<typeof flightSearchSchema>;

const cities = [
  { value: "amm", label: "Amman (AMM)" },
  { value: "dxb", label: "Dubai (DXB)" },
  { value: "cdg", label: "Paris (CDG)" },
  { value: "jfk", label: "New York (JFK)" },
  { value: "lhr", label: "London (LHR)" },
  { value: "cai", label: "Cairo (CAI)" },
];

const passengerOptions = [
  { value: "1", label: "1 Adult" },
  { value: "2", label: "2 Adults" },
  { value: "3", label: "3 Adults" },
  { value: "4+", label: "4+ Adults" },
];

const classOptions = [
  { value: "economy", label: "Economy" },
  { value: "premium-economy", label: "Premium Economy" },
  { value: "business", label: "Business" },
  { value: "first", label: "First Class" },
];

export default function FlightSearchWidget() {
  const { toast } = useToast();
  const [tripType, setTripType] = useState("round-trip");

  const form = useForm<FlightSearchForm>({
    resolver: zodResolver(flightSearchSchema),
    defaultValues: {
      tripType: "round-trip",
      passengers: "1",
      class: "economy",
    },
  });

  const searchMutation = useMutation({
    mutationFn: async (data: FlightSearchForm) => {
      return await apiRequest("POST", "/api/flight-search", data);
    },
    onSuccess: () => {
      toast({
        title: "Search Submitted",
        description: "We'll find the best flights for you!",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Search Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FlightSearchForm) => {
    searchMutation.mutate(data);
  };

  return (
    <Card className="w-full max-w-5xl mx-auto shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-dark-gray text-center">
          Find Your Perfect Flight
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 lg:p-8">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Trip Type Selection */}
            <FormField
              control={form.control}
              name="tripType"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <RadioGroup
                      value={field.value}
                      onValueChange={(value) => {
                        field.onChange(value);
                        setTripType(value);
                      }}
                      className="flex flex-wrap gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="round-trip" id="round-trip" data-testid="radio-round-trip" />
                        <Label htmlFor="round-trip" className="font-medium">Round Trip</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="one-way" id="one-way" data-testid="radio-one-way" />
                        <Label htmlFor="one-way" className="font-medium">One Way</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="multi-city" id="multi-city" data-testid="radio-multi-city" />
                        <Label htmlFor="multi-city" className="font-medium">Multi-City</Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Flight Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* From */}
              <FormField
                control={form.control}
                name="from"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary h-4 w-4" />
                        <Select value={field.value} onValueChange={field.onChange}>
                          <SelectTrigger className="pl-10" data-testid="select-from">
                            <SelectValue placeholder="Select departure city" />
                          </SelectTrigger>
                          <SelectContent>
                            {cities.map((city) => (
                              <SelectItem key={city.value} value={city.value}>
                                {city.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* To */}
              <FormField
                control={form.control}
                name="to"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>To</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary h-4 w-4 rotate-45" />
                        <Select value={field.value} onValueChange={field.onChange}>
                          <SelectTrigger className="pl-10" data-testid="select-to">
                            <SelectValue placeholder="Select destination" />
                          </SelectTrigger>
                          <SelectContent>
                            {cities.map((city) => (
                              <SelectItem key={city.value} value={city.value}>
                                {city.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Departure Date */}
              <FormField
                control={form.control}
                name="departureDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Departure</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary h-4 w-4" />
                        <Input
                          type="date"
                          className="pl-10"
                          data-testid="input-departure-date"
                          {...field}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Return Date */}
              {tripType === "round-trip" && (
                <FormField
                  control={form.control}
                  name="returnDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Return</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary h-4 w-4" />
                          <Input
                            type="date"
                            className="pl-10"
                            data-testid="input-return-date"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>

            {/* Passengers and Class */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="passengers"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Passengers</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary h-4 w-4" />
                        <Select value={field.value} onValueChange={field.onChange}>
                          <SelectTrigger className="pl-10" data-testid="select-passengers">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {passengerOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="class"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Class</FormLabel>
                    <FormControl>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <SelectTrigger data-testid="select-class">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {classOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex items-end">
                <Button
                  type="submit"
                  className="w-full btn-primary text-white py-3 rounded-xl font-semibold text-lg"
                  disabled={searchMutation.isPending}
                  data-testid="button-search-flights"
                >
                  {searchMutation.isPending ? (
                    <>
                      <Search className="mr-2 h-4 w-4 animate-spin" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="mr-2 h-4 w-4" />
                      Search Flights
                    </>
                  )}
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
