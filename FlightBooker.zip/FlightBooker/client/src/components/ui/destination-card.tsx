import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

interface DestinationCardProps {
  destination: {
    id: string;
    name: string;
    country: string;
    description: string;
    price: number;
    image: string;
    currency: string;
  };
  index: number;
}

export default function DestinationCard({ destination, index }: DestinationCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="card-hover bg-white rounded-2xl shadow-lg overflow-hidden h-full">
        <div className="relative">
          <img
            src={destination.image}
            alt={`${destination.name}, ${destination.country}`}
            className="w-full h-48 object-cover"
            data-testid={`img-destination-${destination.id}`}
          />
          <Badge className="absolute top-4 right-4 bg-primary text-white">
            Popular
          </Badge>
        </div>
        <CardContent className="p-6">
          <h3 className="text-xl font-bold text-dark-gray mb-2" data-testid={`text-destination-name-${destination.id}`}>
            {destination.name}, {destination.country}
          </h3>
          <p className="text-gray-600 mb-4" data-testid={`text-destination-description-${destination.id}`}>
            {destination.description}
          </p>
          <div className="flex justify-between items-center">
            <span 
              className="text-primary font-bold text-lg"
              data-testid={`text-destination-price-${destination.id}`}
            >
              From {destination.currency}{destination.price}
            </span>
            <Button 
              className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-opacity-90 transition-colors"
              data-testid={`button-book-${destination.id}`}
            >
              Book Flight
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
