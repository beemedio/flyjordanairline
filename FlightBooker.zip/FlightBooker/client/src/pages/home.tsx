import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import FlightSearchWidget from "@/components/ui/flight-search-widget";
import DestinationCard from "@/components/ui/destination-card";
import FleetCard from "@/components/ui/fleet-card";
import BlogCard from "@/components/ui/blog-card";
import { destinations } from "@/data/destinations";
import { fleet } from "@/data/fleet";
import { blogPosts } from "@/data/blog-posts";
import { Plane, Shield, Armchair, Globe, Play } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const usps = [
    {
      icon: Shield,
      title: "Safety First",
      description: "Highest safety standards with modern aircraft maintenance and experienced crew ensuring your peace of mind.",
      color: "primary",
    },
    {
      icon: Armchair,
      title: "Premium Comfort",
      description: "Spacious seating, premium amenities, and personalized service for a comfortable journey every time.",
      color: "secondary",
    },
    {
      icon: Globe,
      title: "Global Network",
      description: "Connecting you to destinations worldwide with convenient schedules and seamless connections.",
      color: "primary",
    },
    {
      icon: Plane,
      title: "Modern Fleet",
      description: "State-of-the-art aircraft with latest technology, entertainment systems, and fuel-efficient operations.",
      color: "secondary",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="hero-gradient py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold text-dark-gray mb-6">
              FlyJordanAirline
              <span className="block text-primary mt-2">Your Gateway to the World</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Experience premium air travel with our modern fleet, exceptional service, and global network. 
              Discover destinations worldwide with comfort and style.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                className="btn-primary text-white px-8 py-4 rounded-xl font-semibold text-lg"
                data-testid="button-hero-book-flight"
              >
                <Plane className="mr-2 h-5 w-5" />
                Book Your Flight
              </Button>
              <Button 
                variant="outline"
                className="border-2 border-primary text-primary px-8 py-4 rounded-xl font-semibold text-lg hover:bg-primary hover:text-white transition-colors"
                data-testid="button-hero-watch-video"
              >
                <Play className="mr-2 h-5 w-5" />
                Watch Video
              </Button>
            </div>
          </motion.div>

          {/* Flight Search Widget */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <FlightSearchWidget />
          </motion.div>
        </div>
      </section>

      {/* USPs Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">
              Why Choose FlyJordanAirline?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Experience the difference with our commitment to excellence in every aspect of your journey.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {usps.map((usp, index) => {
              const IconComponent = usp.icon;
              return (
                <motion.div
                  key={usp.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * index }}
                >
                  <Card className="text-center card-hover bg-white p-8 rounded-2xl shadow-lg h-full">
                    <CardContent className="p-0">
                      <div className={`w-16 h-16 ${usp.color === 'primary' ? 'bg-primary' : 'bg-secondary'} bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-6`}>
                        <IconComponent className={`text-2xl ${usp.color === 'primary' ? 'text-primary' : 'text-secondary'} h-8 w-8`} />
                      </div>
                      <h3 className="text-xl font-bold text-dark-gray mb-4">{usp.title}</h3>
                      <p className="text-gray-600">{usp.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Destinations Preview */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">
              Popular Destinations
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover amazing destinations around the world with our premium flight services.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {destinations.slice(0, 4).map((destination, index) => (
              <DestinationCard 
                key={destination.id} 
                destination={destination} 
                index={index}
              />
            ))}
          </div>

          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Link href="/destinations" data-testid="link-view-all-destinations">
              <Button 
                variant="outline"
                className="border-2 border-primary text-primary px-8 py-4 rounded-xl font-semibold hover:bg-primary hover:text-white transition-colors"
              >
                View All Destinations
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Fleet Preview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">
              Our Modern Fleet
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Experience comfort and safety with our state-of-the-art aircraft featuring the latest technology.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {fleet.map((aircraft, index) => (
              <FleetCard 
                key={aircraft.id} 
                aircraft={aircraft} 
                index={index}
              />
            ))}
          </div>

          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Link href="/fleet" data-testid="link-explore-full-fleet">
              <Button 
                variant="outline"
                className="border-2 border-primary text-primary px-8 py-4 rounded-xl font-semibold hover:bg-primary hover:text-white transition-colors"
              >
                Explore Full Fleet
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Blog Preview */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">
              Travel Insights & News
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Stay updated with the latest travel tips, destination guides, and airline news from our experts.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.slice(0, 3).map((post, index) => (
              <BlogCard 
                key={post.id} 
                post={post} 
                index={index}
              />
            ))}
          </div>

          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Link href="/blog" data-testid="link-view-all-articles">
              <Button 
                variant="outline"
                className="border-2 border-primary text-primary px-8 py-4 rounded-xl font-semibold hover:bg-primary hover:text-white transition-colors"
              >
                View All Articles
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-20 bg-gradient-to-r from-primary to-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready for Your Next Adventure?
            </h2>
            <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto">
              Join millions of satisfied passengers who choose FlyJordanAirline for their travel needs. 
              Book your flight today and experience the difference.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                className="bg-white text-primary px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-colors"
                data-testid="button-cta-book-flight"
              >
                <Plane className="mr-2 h-5 w-5" />
                Book Your Flight
              </Button>
              <Button 
                variant="outline"
                className="border-2 border-white text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-white hover:text-primary transition-colors"
                data-testid="button-cta-special-offers"
              >
                View Special Offers
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
