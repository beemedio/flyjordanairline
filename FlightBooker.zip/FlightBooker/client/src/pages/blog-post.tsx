import { useParams, Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { blogPosts } from "@/data/blog-posts";
import { 
  Calendar, 
  Clock, 
  ArrowLeft, 
  Share2, 
  Facebook, 
  Twitter, 
  Linkedin,
  ChevronLeft,
  ChevronRight,
  List,
  User
} from "lucide-react";

interface BlogPostType {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  image: string;
  slug: string;
  lead: string;
  content: string;
}

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = blogPosts.find(p => p.slug === slug) as BlogPostType | undefined;

  if (!post) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-600 mb-4">Article Not Found</h1>
          <p className="text-gray-500 mb-8">The article you're looking for doesn't exist.</p>
          <Link href="/blog" data-testid="link-back-to-blog">
            <Button className="bg-primary text-white px-6 py-3 rounded-xl">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Blog
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Extract headings for table of contents
  const headings = post.content.match(/^#{2,3}\s+(.+)$/gm)?.map(heading => {
    const level = heading.match(/^#{2,3}/)?.[0].length || 2;
    const text = heading.replace(/^#{2,3}\s+/, '');
    const slug = text.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, '-');
    return { level, text, slug };
  }) || [];

  const categoryColors = {
    "Travel Tips": "bg-primary text-white",
    "Destinations": "bg-secondary text-white", 
    "Airline News": "bg-primary text-white",
  };

  // Process content with proper formatting
  const processContent = (content: string) => {
    return content
      .replace(/^## (.+)$/gm, '<h2 id="$1" class="text-2xl font-bold text-gray-900 mt-8 mb-4">$1</h2>')
      .replace(/^### (.+)$/gm, '<h3 id="$1" class="text-xl font-semibold text-gray-800 mt-6 mb-3">$1</h3>')
      .replace(/\*\*(.+?)\*\*/g, '<strong class="font-semibold text-gray-900">$1</strong>')
      .replace(/^\* (.+)$/gm, '<li class="mb-2 text-gray-700">$1</li>')
      .replace(/\n\n/g, '</p><p class="text-gray-700 leading-relaxed mb-4">')
      .replace(/^(?!<[h|l])(.+)$/gm, '<p class="text-gray-700 leading-relaxed mb-4">$1</p>')
      .replace(/<li/g, '<ul class="list-disc list-inside space-y-2 mb-6 ml-4"><li')
      .replace(/li>/g, 'li></ul>')
      .replace(/<\/ul><ul[^>]*>/g, '');
  };

  const processLead = (lead: string) => {
    return lead
      .replace(/\*\*(.+?)\*\*/g, '<strong class="font-semibold">$1</strong>')
      .replace(/\n\n/g, '</p><p class="text-xl text-gray-600 leading-relaxed mb-4">')
      .replace(/^(.+)$/gm, '<p class="text-xl text-gray-600 leading-relaxed mb-4">$1</p>');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <section className="hero-gradient py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Link href="/blog" data-testid="link-back-to-blog">
              <Button variant="ghost" className="mb-8 text-gray-600 hover:text-primary">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Blog
              </Button>
            </Link>

            <div className="mb-6">
              <Badge 
                className={categoryColors[post.category as keyof typeof categoryColors] || "bg-primary text-white"}
                data-testid="badge-post-category"
              >
                {post.category}
              </Badge>
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-8 leading-tight" data-testid="text-post-title">
              {post.title}
            </h1>

            <div className="flex flex-wrap items-center gap-6 text-gray-600 mb-8">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                <span className="text-base" data-testid="text-post-date">{post.date}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                <span className="text-base" data-testid="text-post-read-time">{post.readTime} read</span>
              </div>
              <Button variant="outline" size="sm" className="flex items-center gap-2 border-gray-300 text-gray-600 hover:bg-gray-100 hover:text-gray-800 transition-colors" data-testid="button-share">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Image */}
      <section className="py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <img
              src={post.image}
              alt={post.title}
              className="w-full h-64 md:h-96 object-cover rounded-2xl shadow-xl"
              data-testid="img-post-featured"
            />
          </motion.div>
        </div>
      </section>

      {/* Article Content */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
              {/* Main Content */}
              <div className="lg:col-span-3">
                {/* Lead */}
                <div 
                  className="mb-12 pb-8 border-b border-gray-200"
                  dangerouslySetInnerHTML={{ __html: processLead(post.lead) }}
                  data-testid="text-post-lead"
                />

                {/* Content */}
                <div 
                  className="prose prose-lg max-w-none"
                  dangerouslySetInnerHTML={{ __html: processContent(post.content) }}
                  data-testid="text-post-content"
                />
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="sticky top-8 space-y-6">
                  {/* Table of Contents */}
                  {headings.length > 0 && (
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <List className="h-5 w-5 text-primary" />
                          <h3 className="font-bold text-gray-900">Table of Contents</h3>
                        </div>
                        <ul className="space-y-2 text-sm">
                          {headings.map((heading, index) => (
                            <li key={index} className={heading.level === 3 ? "ml-4" : ""}>
                              <a 
                                href={`#${heading.slug}`} 
                                className="text-gray-600 hover:text-primary transition-colors leading-relaxed block py-1"
                                data-testid={`link-toc-${index}`}
                              >
                                {heading.text}
                              </a>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}

                  {/* Share Buttons */}
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-bold text-gray-900 mb-4">Share this article</h3>
                      <div className="space-y-3">
                        <Button variant="outline" className="w-full justify-start border-gray-300 text-gray-600 hover:bg-gray-100 hover:text-gray-800" data-testid="button-share-facebook">
                          <Facebook className="mr-2 h-4 w-4" />
                          Facebook
                        </Button>
                        <Button variant="outline" className="w-full justify-start border-gray-300 text-gray-600 hover:bg-gray-100 hover:text-gray-800" data-testid="button-share-twitter">
                          <Twitter className="mr-2 h-4 w-4" />
                          Twitter
                        </Button>
                        <Button variant="outline" className="w-full justify-start border-gray-300 text-gray-600 hover:bg-gray-100 hover:text-gray-800" data-testid="button-share-linkedin">
                          <Linkedin className="mr-2 h-4 w-4" />
                          LinkedIn
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Author Box */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <Card>
              <CardContent className="p-8">
                <div className="flex items-start gap-6">
                  <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="h-10 w-10 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-2" data-testid="text-author-name">
                      Travel Expert Team
                    </h3>
                    <p className="text-gray-600 leading-relaxed mb-4" data-testid="text-author-bio">
                      Our team of travel experts brings years of experience in international travel, airline regulations, and health guidelines. We research and verify all information to provide you with accurate, up-to-date travel advice.
                    </p>
                    <div className="flex items-center gap-4">
                      <Badge variant="secondary" className="text-sm">Travel Expert</Badge>
                      <Badge variant="secondary" className="text-sm">Health & Safety</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Back to Blog */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Link href="/blog" data-testid="link-back-to-blog-bottom">
              <Button size="lg" className="bg-primary text-white px-8 py-3 rounded-xl font-semibold">
                <ArrowLeft className="mr-2 h-5 w-5" />
                Back to All Articles
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}