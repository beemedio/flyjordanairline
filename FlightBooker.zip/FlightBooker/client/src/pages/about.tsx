import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  History, 
  Award, 
  Users, 
  Shield, 
  Globe, 
  Plane, 
  Heart,
  CheckCircle
} from "lucide-react";

export default function About() {
  const milestones = [
    {
      year: "1995",
      title: "Founded",
      description: "FlyJordanAirline was established with a vision to connect Jordan to the world through premium air travel."
    },
    {
      year: "2000",
      title: "First International Route",
      description: "Launched our first international service connecting Amman to Paris, marking our entry into European markets."
    },
    {
      year: "2010",
      title: "Fleet Modernization",
      description: "Introduced our first Boeing 787 Dreamliner, beginning our commitment to modern, fuel-efficient aircraft."
    },
    {
      year: "2018",
      title: "Network Expansion",
      description: "Reached 50 destinations worldwide, establishing FlyJordanAirline as a leading regional carrier."
    },
    {
      year: "2023",
      title: "Premium Economy Launch",
      description: "Introduced our enhanced Premium Economy service, offering exceptional value and comfort."
    }
  ];

  const values = [
    {
      icon: Shield,
      title: "Safety Excellence",
      description: "Safety is our top priority. We maintain the highest standards through rigorous training, advanced technology, and comprehensive maintenance programs.",
      color: "primary"
    },
    {
      icon: Heart,
      title: "Legendary Hospitality",
      description: "Our service reflects the warmth and generosity of Jordanian culture, ensuring every passenger feels welcomed and valued.",
      color: "secondary"
    },
    {
      icon: CheckCircle,
      title: "Operational Excellence",
      description: "We strive for perfection in every aspect of our operation, from on-time performance to service quality.",
      color: "primary"
    },
    {
      icon: Globe,
      title: "Global Connectivity",
      description: "Connecting Jordan to the world and bringing the world to Jordan through our expanding network of destinations.",
      color: "secondary"
    }
  ];

  const leadership = [
    {
      name: "Ahmad Al-Rashid",
      position: "Chief Executive Officer",
      description: "Leading FlyJordanAirline with over 20 years of aviation industry experience.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
    },
    {
      name: "Layla Mansour",
      position: "Chief Operating Officer",
      description: "Ensuring operational excellence and safety across all aspects of our airline operations.",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
    },
    {
      name: "Omar Khalil",
      position: "Chief Safety Officer",
      description: "Maintaining the highest safety standards and implementing cutting-edge safety technologies.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <section className="hero-gradient py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold text-dark-gray mb-6">
              About <span className="text-primary">FlyJordanAirline</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Since our founding, FlyJordanAirline has been committed to connecting people and cultures 
              across the globe. We combine traditional Jordanian hospitality with modern aviation excellence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-6">Our Mission</h2>
              <p className="text-xl text-gray-600 mb-8">
                To provide safe, reliable, and exceptional air travel experiences that connect Jordan 
                to the world while showcasing the best of Jordanian hospitality and service excellence.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <Globe className="text-primary h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-dark-gray mb-2">Global Connectivity</h3>
                    <p className="text-gray-600">Linking Jordan to major destinations worldwide with convenient connections.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-secondary bg-opacity-10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <Heart className="text-secondary h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-dark-gray mb-2">Cultural Ambassador</h3>
                    <p className="text-gray-600">Sharing Jordan's rich heritage and warm hospitality with the world.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <Award className="text-primary h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-dark-gray mb-2">Service Excellence</h3>
                    <p className="text-gray-600">Delivering premium service that exceeds passenger expectations.</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1556388158-158ea5ccacbd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Modern aircraft representing our mission" 
                className="rounded-2xl shadow-xl w-full"
                data-testid="img-mission"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent rounded-2xl"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Company Timeline */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">Our Journey</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From our humble beginnings to becoming a leading regional airline, 
              discover the key milestones in our growth story.
            </p>
          </motion.div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-0.5 h-full bg-primary opacity-30"></div>
            
            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <motion.div
                  key={milestone.year}
                  className={`relative flex items-center ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  {/* Timeline dot */}
                  <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-8 h-8 bg-primary rounded-full flex items-center justify-center z-10">
                    <div className="w-4 h-4 bg-white rounded-full"></div>
                  </div>
                  
                  {/* Content */}
                  <div className={`w-full md:w-5/12 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'} pl-16 md:pl-0`}>
                    <Card className="bg-white shadow-lg">
                      <CardContent className="p-6">
                        <div className="text-2xl font-bold text-primary mb-2" data-testid={`text-milestone-year-${index}`}>
                          {milestone.year}
                        </div>
                        <h3 className="text-xl font-bold text-dark-gray mb-3" data-testid={`text-milestone-title-${index}`}>
                          {milestone.title}
                        </h3>
                        <p className="text-gray-600" data-testid={`text-milestone-description-${index}`}>
                          {milestone.description}
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Company Values */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">Our Core Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              These fundamental principles guide every decision we make and every service we provide.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="card-hover bg-white p-8 rounded-2xl shadow-lg h-full">
                    <CardContent className="p-0">
                      <div className={`w-16 h-16 ${value.color === 'primary' ? 'bg-primary' : 'bg-secondary'} bg-opacity-10 rounded-full flex items-center justify-center mb-6`}>
                        <IconComponent className={`${value.color === 'primary' ? 'text-primary' : 'text-secondary'} h-8 w-8`} />
                      </div>
                      <h3 className="text-xl font-bold text-dark-gray mb-4" data-testid={`text-value-title-${index}`}>
                        {value.title}
                      </h3>
                      <p className="text-gray-600" data-testid={`text-value-description-${index}`}>
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">Leadership Team</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Meet the experienced professionals who guide FlyJordanAirline's vision and operations.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {leadership.map((leader, index) => (
              <motion.div
                key={leader.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="card-hover bg-white rounded-2xl shadow-lg overflow-hidden">
                  <img
                    src={leader.image}
                    alt={leader.name}
                    className="w-full h-64 object-cover"
                    data-testid={`img-leader-${index}`}
                  />
                  <CardContent className="p-6 text-center">
                    <h3 className="text-xl font-bold text-dark-gray mb-2" data-testid={`text-leader-name-${index}`}>
                      {leader.name}
                    </h3>
                    <div className="text-primary font-semibold mb-4" data-testid={`text-leader-position-${index}`}>
                      {leader.position}
                    </div>
                    <p className="text-gray-600" data-testid={`text-leader-description-${index}`}>
                      {leader.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">
              Join Our Journey
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Be part of the FlyJordanAirline story. Whether you're a passenger, partner, or future team member, 
              we invite you to experience the difference.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                className="bg-primary text-white px-8 py-4 rounded-xl font-semibold text-lg"
                data-testid="button-careers"
              >
                <Users className="mr-2 h-5 w-5" />
                Explore Careers
              </Button>
              <Button 
                variant="outline"
                className="border-2 border-primary text-primary px-8 py-4 rounded-xl font-semibold text-lg hover:bg-primary hover:text-white transition-colors"
                data-testid="button-contact-us"
              >
                Contact Us
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
