import { useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import DestinationCard from "@/components/ui/destination-card";
import { destinations } from "@/data/destinations";
import { Search, Filter } from "lucide-react";

export default function Destinations() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [filterRegion, setFilterRegion] = useState("all");

  const regions = [
    { value: "all", label: "All Regions" },
    { value: "middle-east", label: "Middle East" },
    { value: "europe", label: "Europe" },
    { value: "north-america", label: "North America" },
    { value: "africa", label: "Africa" },
  ];

  const getRegion = (country: string) => {
    const regionMap: { [key: string]: string } = {
      "Jordan": "middle-east",
      "UAE": "middle-east", 
      "France": "europe",
      "UK": "europe",
      "USA": "north-america",
      "Egypt": "africa",
    };
    return regionMap[country] || "other";
  };

  const filteredDestinations = destinations
    .filter(dest => {
      const matchesSearch = dest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           dest.country.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesRegion = filterRegion === "all" || getRegion(dest.country) === filterRegion;
      return matchesSearch && matchesRegion;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "price":
          return a.price - b.price;
        case "country":
          return a.country.localeCompare(b.country);
        default:
          return a.name.localeCompare(b.name);
      }
    });

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <section className="hero-gradient py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold text-dark-gray mb-6">
              Discover Amazing <span className="text-primary">Destinations</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore the world with FlyJordanAirline. From bustling cities to serene beaches, 
              we connect you to unforgettable experiences worldwide.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filters and Search */}
      <section className="py-8 bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="flex flex-col md:flex-row gap-4 items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Search destinations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search-destinations"
              />
            </div>

            {/* Region Filter */}
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <Select value={filterRegion} onValueChange={setFilterRegion}>
                <SelectTrigger className="w-48" data-testid="select-filter-region">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {regions.map((region) => (
                    <SelectItem key={region.value} value={region.value}>
                      {region.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Sort */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-32" data-testid="select-sort-by">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="country">Country</SelectItem>
                  <SelectItem value="price">Price</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Destinations Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredDestinations.length === 0 ? (
            <motion.div 
              className="text-center py-20"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
            >
              <h3 className="text-2xl font-bold text-gray-600 mb-4">No destinations found</h3>
              <p className="text-gray-500 mb-8">Try adjusting your search or filter criteria.</p>
              <Button 
                onClick={() => {
                  setSearchTerm("");
                  setFilterRegion("all");
                  setSortBy("name");
                }}
                className="bg-primary text-white px-6 py-3 rounded-xl"
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredDestinations.map((destination, index) => (
                <DestinationCard 
                  key={destination.id} 
                  destination={destination} 
                  index={index}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">
              Can't Find Your Destination?
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              We're constantly expanding our network. Contact us about new routes or 
              let us help you plan your perfect journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                className="bg-primary text-white px-8 py-4 rounded-xl font-semibold text-lg"
                data-testid="button-contact-us"
              >
                Contact Us
              </Button>
              <Button 
                variant="outline"
                className="border-2 border-primary text-primary px-8 py-4 rounded-xl font-semibold text-lg hover:bg-primary hover:text-white transition-colors"
                data-testid="button-view-all-routes"
              >
                View All Routes
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
