export const fleet = [
  {
    id: "boeing-787-9",
    name: "Boeing 787-9 Dreamliner",
    type: "Long-haul",
    passengers: 290,
    range: 14800,
    image: "https://images.unsplash.com/photo-1556388158-158ea5ccacbd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=400",
    amenities: ["Wi-Fi", "Entertainment", "Power Outlets", "Premium Dining"],
  },
  {
    id: "airbus-a321neo",
    name: "Airbus A321neo",
    type: "Regional",
    passengers: 220,
    range: 7400,
    image: "https://images.unsplash.com/photo-1544636331-e26879cd4d9b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=400",
    amenities: ["Wi-Fi", "Entertainment", "Extra Legroom", "Quick Boarding"],
  },
];
