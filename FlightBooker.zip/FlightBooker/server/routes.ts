import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSubmissionSchema, insertFlightSearchSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      const submission = await storage.createContactSubmission(validatedData);
      res.json({ success: true, id: submission.id });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Invalid form data", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Failed to submit contact form" 
        });
      }
    }
  });

  // Flight search submission
  app.post("/api/flight-search", async (req, res) => {
    try {
      const validatedData = insertFlightSearchSchema.parse(req.body);
      const search = await storage.createFlightSearch(validatedData);
      res.json({ success: true, id: search.id });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Invalid search data", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Failed to submit flight search" 
        });
      }
    }
  });

  // Get contact submissions (admin)
  app.get("/api/contact-submissions", async (req, res) => {
    try {
      const submissions = await storage.getContactSubmissions();
      res.json(submissions);
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: "Failed to fetch contact submissions" 
      });
    }
  });

  // Get flight searches (admin)
  app.get("/api/flight-searches", async (req, res) => {
    try {
      const searches = await storage.getFlightSearches();
      res.json(searches);
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: "Failed to fetch flight searches" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
