import { type User, type InsertUser, type ContactSubmission, type InsertContactSubmission, type FlightSearch, type InsertFlightSearch } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  createFlightSearch(search: InsertFlightSearch): Promise<FlightSearch>;
  getContactSubmissions(): Promise<ContactSubmission[]>;
  getFlightSearches(): Promise<FlightSearch[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private contactSubmissions: Map<string, ContactSubmission>;
  private flightSearches: Map<string, FlightSearch>;

  constructor() {
    this.users = new Map();
    this.contactSubmissions = new Map();
    this.flightSearches = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = randomUUID();
    const submission: ContactSubmission = { 
      ...insertSubmission, 
      id,
      createdAt: new Date()
    };
    this.contactSubmissions.set(id, submission);
    return submission;
  }

  async createFlightSearch(insertSearch: InsertFlightSearch): Promise<FlightSearch> {
    const id = randomUUID();
    const search: FlightSearch = { 
      ...insertSearch, 
      id,
      createdAt: new Date(),
      returnDate: insertSearch.returnDate || null
    };
    this.flightSearches.set(id, search);
    return search;
  }

  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return Array.from(this.contactSubmissions.values()).sort(
      (a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
    );
  }

  async getFlightSearches(): Promise<FlightSearch[]> {
    return Array.from(this.flightSearches.values()).sort(
      (a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
    );
  }
}

export const storage = new MemStorage();
